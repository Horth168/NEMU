#ifndef __SHL_H__
#define __SHL_H__

make_helper(shl_rm_1_b);
make_helper(shl_rm_cl_b);
make_helper(shl_rm_imm_b);

make_helper(shl_rm_1_v);
make_helper(shl_rm_cl_v);
make_helper(shl_rm_imm_v);
#endif
