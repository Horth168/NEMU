#ifndef __CALL_H__
#define __CALL_H__

make_helper(call_si);
make_helper(call_rm);

#endif