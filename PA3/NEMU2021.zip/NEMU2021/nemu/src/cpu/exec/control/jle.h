#ifndef __JLE_H__
#define __JLE_H__

make_helper(jle_i_b);
make_helper(jle_i_v);

#endif
