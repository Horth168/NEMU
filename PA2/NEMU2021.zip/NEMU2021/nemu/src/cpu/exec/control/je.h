#ifndef __JE_H__
#define __JE_H__

make_helper(je_i_b);
make_helper(je_i_v);

#endif