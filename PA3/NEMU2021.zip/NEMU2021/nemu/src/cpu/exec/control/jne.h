#ifndef __JNE_H__
#define __JNE_H__

make_helper(jne_i_b);
make_helper(jne_i_v);

#endif