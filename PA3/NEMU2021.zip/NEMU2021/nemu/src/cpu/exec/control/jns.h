#ifndef __JNS_H__
#define __JNS_H__

make_helper(jns_i_b);
make_helper(jns_i_v);

#endif
