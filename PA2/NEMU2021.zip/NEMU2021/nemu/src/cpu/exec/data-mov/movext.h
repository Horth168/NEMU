#ifndef __MOVEXT_H__
#define __MOVEXT_H__

make_helper(movzw_l);
make_helper(movsw_l);

make_helper(movzb_v);
make_helper(movsb_v);

#endif
