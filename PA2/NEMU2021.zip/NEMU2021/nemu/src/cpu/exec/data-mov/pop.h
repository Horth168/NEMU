#ifndef __POP_H__
#define __POP_H__


make_helper(pop_r_v);

#endif
