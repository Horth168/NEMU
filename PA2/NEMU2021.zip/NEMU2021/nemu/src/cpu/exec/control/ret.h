#ifndef __RET_H__
#define __RET_H__

make_helper(ret);
make_helper(ret_i);

#endif
