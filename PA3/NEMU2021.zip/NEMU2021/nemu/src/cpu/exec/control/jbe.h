#ifndef __JBE_H__
#define __JBE_H__

make_helper(jbe_i_b);
make_helper(jbe_i_v);

#endif
