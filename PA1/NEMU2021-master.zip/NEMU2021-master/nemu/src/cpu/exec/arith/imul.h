#ifndef __IMUL_H__
#define __IMUL_H__

make_helper(imul_rm2a_b);

make_helper(imul_rm2a_v);
make_helper(imul_rm2r_v);
make_helper(imul_si_rm2r_v);
make_helper(imul_i_rm2r_v);

#endif
