#ifndef __LEAVE_H__
#define __LEAVE_H__

make_helper(leave);

#endif