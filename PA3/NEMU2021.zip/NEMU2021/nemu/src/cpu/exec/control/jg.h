#ifndef __JG_H__
#define __JG_H__

make_helper(jg_i_b);
make_helper(jg_i_v);

#endif
