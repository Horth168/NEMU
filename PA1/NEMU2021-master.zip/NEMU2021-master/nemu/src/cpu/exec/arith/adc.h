#ifndef __ADC_H__
#define __ADC_H__

make_helper(adc_r2rm_v);

#endif
