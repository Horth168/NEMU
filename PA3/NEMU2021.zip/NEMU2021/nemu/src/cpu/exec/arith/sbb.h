#ifndef __SBB_H__
#define __SBB_H__

make_helper(sbb_i2a_b);
make_helper(sbb_i2rm_b);
make_helper(sbb_r2rm_b);
make_helper(sbb_rm2r_b);
make_helper(sbb_i2a_v);
make_helper(sbb_i2rm_v);
make_helper(sbb_r2rm_v);
make_helper(sbb_rm2r_v);
make_helper(sbb_si2rm_v);

#endif
